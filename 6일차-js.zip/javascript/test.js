/*
프로그래밍 - 내가 할 동작 - 한글로 정리 -> 프로그래밍 언어 번역
*/

// 1) 요소선택
// 선택해올 때 단수 vs 복수 구분
// 복수로 가져오는 것은 [0]형식의 인덱스번호 붙여주어야 함.

// 1-1) 태그
let tagDiv = document.getElementsByTagName('section')
console.log(tagDiv)

// 1-2) 클래스
let classBox = document.getElementsByClassName('box')
console.log(classBox)

// 1-3) css선택자로 - 복수개 선택하는 방법
let queryInner = document.querySelectorAll('.inner');
console.log(queryInner)


// 1-4) 아이디 선택자로 가져오기 - 단수
let idToggle = document.getElementById('toggle')
console.log(idToggle)

// 1-5) css선택자로 - 단수로 가져오기
// - 찾은 것중에 첫번째만 찾아준다
let queryContent = document.querySelector('.content')
console.log(queryContent)


// 2) 이벤트연결 (3가지 정도 있음)
// 요소.addEventListener('이벤트', function(){
//   실행할 기능
// });

// 이벤트 연결 - 단수
idToggle.addEventListener('click', function(){});
queryContent.addEventListener('focus', function(){});

// 이벤트 연결 - 복수, 반드시 인덱스번호 지정을 해줘야 한다.
// classBox.addEventListener('click', function(){}) --x

classBox[0].addEventListener('click', function(){})
queryInner[1].addEventListener('keyup', function(){})

// 3) css 바꾸기

// 요소.style.속성 = '값'
// ex) font-size  (카멜스타일로 써주기)
// 요소.style.fontSize = '24px'

queryInner[0].style.color = 'red';
idToggle.style.display = 'block';