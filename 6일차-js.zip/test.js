
i = i+1

i++


for(let i = 0; i < menu.length ; i++){

  menu[i].addEventListener('click', function(){
    let panel = this.nextElementSibling;
    menuClose(i, menu) // 전체패널닫기
    menuOpen(menu[i], panel) // 클릭한 패널 열기
    
  });

}



menu[0].addEventListener('click', function(){
  let panel = this.nextElementSibling;
  menuClose(i, menu) // 전체패널닫기
  menuOpen(menu[i], panel) // 클릭한 패널 열기
  
});

menu[1].addEventListener('click', function(){
  let panel = this.nextElementSibling;
  menuClose(i, menu) // 전체패널닫기
  menuOpen(menu[i], panel) // 클릭한 패널 열기
  
});

menu[2].addEventListener('click', function(){
  let panel = this.nextElementSibling;
  menuClose(i, menu) // 전체패널닫기
  menuOpen(menu[i], panel) // 클릭한 패널 열기
  
});

