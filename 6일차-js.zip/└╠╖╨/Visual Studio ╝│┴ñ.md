# [설정하기] ctrl + ,

1) hover 검색
- Editor › Hover: Enabled / 호버 표시 여부를 제어합니다.
-> 체크해제

2) wrap 검색
- Editor: Word Wrap / 줄 바꿈 여부를 제어합니다.
-> on 설정 : 자동 줄바꿈

3) brow 로 검색
- Editor: Default Formatter
다른 모든 포맷터 설정보다 우선하는 기본 포맷터를 정의합니다. 포맷터를 제공하는 확장 프로그램의 식별자 여야합니다.
-> prettier - code Fommater 설정
-> 프리티어 확장기능 다운 받은 것으로 코드 정렬

4) brow 로 검색
- Live Server › Settings: Custom Browser
-> 라이브 서버 확장기능 - 기본 브라우저 설정 - 크롬