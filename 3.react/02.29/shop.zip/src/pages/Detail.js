
function Detail(props){

  return(
    <>
      <section className='visual'>
      </section>
      {/* 디테일 */}
      <section className='sec detail'>
        <div className='container'>
          <div className='row'>
            디테일 내용
          </div>
        </div>
      </section>
    </>
  )
}
export default Main

