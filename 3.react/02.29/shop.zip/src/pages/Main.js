

import Item from '../component/Item'

function Main(props){
  let shoes = props.shoes

  return(
    <>
      
      <section className='visual'>
      </section>
      <section className='sec'>
        <div className='container'>
          <div className='row'>
            {
              shoes.map((e, i)=>{
                return(
                  <Item key={e.id} item={e} i={i}></Item>                
                )
              })
            }
          </div>
        </div>
      </section>
    </>
  )
}
export default Main

