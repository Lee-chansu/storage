import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import data from './data.js'
import { useState } from 'react';
import { Routes, Route, Link, useNavigate, Outlet} from 'react-router-dom';
import Main from './pages/Main.js'
import Header from './component/Header'

function App() {
  let [shoes] = useState(data)
  let navigate = useNavigate()

  return (
    <>
      <Header></Header>
      <button onClick={()=>{ navigate('/detail') }}>이동버튼</button>
      <Routes>
        <Route path="/" element={<Main shoes={shoes}></Main>}></Route>
        <Route path="/detail" element={<div>datail</div>}></Route>
        <Route path="/about" element={<div>about</div>}></Route>
      </Routes>
      
    </>
  )
}


export default App;
