import {Nav, Navbar, Container} from 'react-bootstrap'

function Header(){
  return(
    <header>
      <Navbar bg="light" data-bs-theme="light">
        <Container>
          <Navbar.Brand href="/">Home</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link href="/About">About</Nav.Link>
            <Nav.Link href="/Detail">Detail</Nav.Link>
          </Nav>
        </Container>
      </Navbar>
    </header>
  )
}

export default Header;