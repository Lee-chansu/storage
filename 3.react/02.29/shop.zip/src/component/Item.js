
function Item(props){
  let {item, i} = props
  return(
    <>
      <div className='col-md-4'>
        <img src={process.env.PUBLIC_URL + '/img/shoes'+ (i+1) +'.jpg'}></img>
        <h3>{item.title}</h3>
        <p>{item.content}</p>
      </div>
    </>
  )
}

export default Item;