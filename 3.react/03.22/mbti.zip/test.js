let num = Math.floor(Math.random() * 256);
let hex = num.toString(16).padStart(3, '0').toUpperCase();
console.log(hex)