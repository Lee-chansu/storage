import { useState } from 'react';
import './ReviewList.css';
import ReviewForm from './ReviewForm';

function formatDate(value) {
  const date = new Date(value);
  return `${date.getFullYear()}. ${date.getMonth() + 1}. ${date.getDate()}`;
}

function ReviewListItem(props){
  const { item, onEdit  } = props

  const handleEditClick = () => {
    onEdit(item.id);
  };

  return(
    <div className="ReviewListItem">
      <img className="ReviewListItem-img" src={item.imgUrl} alt={item.title} />
      <div>
        <h1>{item.title}</h1>
        <p>{item.rating}</p>
        <p>{formatDate(item.createdAt)}</p>
        <p>{item.content}</p>
        <button onClick={handleEditClick}>수정</button>
        <button>삭제</button>
      </div>
    </div>
  )
}

function ReviewList({ items, onUpdate, onUpdateSuccess }){
 
  const [editingId, setEditingId] = useState(null)
  const handleCancel = ()=>{setEditingId(null)}

  return(
    <ul>
    {
      items.map((el)=>{
        // 수정 데이터
        if(el.id === editingId){
          const {id, title, rating, content, imgUrl} = el;
          const initialValues = { title, rating, content, imgFile: null }

          const handleSubmit =(formData)=> onUpdate(id,formData)
          
          const handleSubmitSuccess = (review) => {
            onUpdateSuccess(review);
            setEditingId(null);
          };

          return(
            <li key={el.id}>
            <ReviewForm
              initialValues={initialValues}
              initialPreview={imgUrl}
              onSubmit={handleSubmit}
              onSubmitSuccess={handleSubmitSuccess}
              onCancel={handleCancel}
            />
          </li>
          )
        } 
        // 수정하는 데이터가 아닐때
        return(
          <li key={el.id}>
            <ReviewListItem 
              item = {el}
              onEdit = {setEditingId}
            />
          </li>
        )
      })    
    }
    </ul>
  )
}

export default ReviewList;