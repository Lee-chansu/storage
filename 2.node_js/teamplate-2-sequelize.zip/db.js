// db정보 
module.exports = {
  host: 'localhost',
  user: 'root',
  password: '1234',
  database: 'mall',
  dateStrings: 'date'
}