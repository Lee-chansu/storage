let del = document.getElementsByClassName('del')[0]

  // 콜백함수의 매개변수로 이벤트에 관련된 정보를 넘겨준다
del.addEventListener('click', function(e){
  
  let id = e.target.dataset.id

  // fetch 서버로 요청 날려주는 함수
  fetch('/member/'+id, {method : 'DELETE'}) 
  .then( r => r.text())
  .then( r => {
    // 성공했을때 실행하는 결과
    console.log(r)
    // window.location.href="/member" // 해당url로 이동해라
  })
  .catch(err => { 
    console.log(err)
  })
})