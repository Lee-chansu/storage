// 1. 모듈 - require
const express = require('express')
const app = express()

// db 접속
const db = require('./models')
const {Member} = db

// 2. use, set - 등록
app.set('view engine', 'ejs')
app.use(express.static(__dirname + '/public'))

app.use(express.json()) // json형태로 데이터 처리
app.use(express.urlencoded({extended : true}))  // queryString 방식의 데이터 처리

// 3. listen - 포트번호 지정
app.listen(3000 , ()=>{
  console.log('member 접속! - http://localhost:3000/member')
  console.log('member 접속! - http://localhost:3000/member/1')
   
})


// 4. 하위페이지들 - 라우팅 

app.get('/', (req, res)=>{
  res.send('메인 접속성공!')
})

// 쿼리스트링 - 데이터 조회
app.get('/member', async(req, res)=>{
  
  const {id, team, position} = req.query
  

  let member = null;
  if(id){
    member = await Member.findAll({where : {id}})
  }
  else if(team){
    member = await Member.findAll({where : {team}})
  }
  else if(position){
    member = await Member.findAll({where : {position}})
  }
  else{
    member = await  Member.findAll()
  }
  res.render('member.ejs', {member})
})


// 파라미터로 - 데이터 조회
app.get('/member/:id', async(req, res)=>{
  res.render('member.ejs',{member})
  const {id} = req.params
  const member = await  Member.findAll({where: {id : id}}) // 한개씩 값을 찾을 때 - findOne
  
  console.log(id)

  if(member){
    res.render('member.ejs', {member})
  } else{
    res.status(404).send({message : 'I cannot search!'})
  }

})


// 데이터 추가
app.post('/member', async( req, res )=>{
  const newMember = req.body 
  const member = Member.build(newMember) 
  // member.name = "Alice" // 수정후 save
  await member.save()
  res.render('member.ejs', {member})

  /* 
  //case2
  const newMember = req.body 
  const member = await Member.create(newMember)   // build + save
  res.render('member.ejs', {member})

  */
})




/* 

http://localhost:3000/member?name=hong&age=30

req.body = queryString로 들어온 데이터가 객체형태로 저장이 되어 있음
newMember에 저장
Member모델과 연결된 테이블에 들어갈 수 있는 형태로 build해준다.
member 저장 ( = 테이블에 row 추가)
테이블 추가 -  save()메서드를 통해 최종 테이블에 추가
 */




/* app.put('/member/:id', async(req, res)=>{
  
  const {id} = req.params
  const newInfo = req.body
  const result = await Member.update(newInfo, {where : {id}})

  if(result[0]){
    res.send({message : `${result[0]} row(s) affeted`})
  }else{
    res.status(404).send({message : 'i cannot find the id!'})
  }

}) */

// 찾는 id값이 있다면 첫번째 데이터가 되니까 0번지의 데이터임
// 그래서 result[0] === 찾는 데이터가 있다


app.put('/member/:id', async(req, res)=>{

  const {id} = req.params
  const newInfo = req.body
  const member = await Member.findOne({where : {id}})

  Object.keys(newInfo).forEach((prop)=>{
    member[prop] = newInfo[prop]
  })
  await member.save()
  res.send(member)
})


app.delete('/member/:id', async (req, res)=>{

  const {id} = req.params
  const deleteCount = await Member.destroy({where : {id}})
  
  if(deleteCount){
    res.send({message : `${deleteCount} row(s) Deleted`})
  } else{
    res.status(404).send({massage : 'i cannto find the id!'})
  }

})