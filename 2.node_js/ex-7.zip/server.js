// 1. 모듈 - require
const express = require('express')
const app = express()

// db 접속
const db = require('./models')
const {Member} = db

// 2. use, set - 등록
app.set('view engine', 'ejs')
app.use(express.static(__dirname + '/public'))

app.use(express.json()) // json형태로 데이터 처리
app.use(express.urlencoded({extended : true}))  // queryString 방식의 데이터 처리

// 3. listen - 포트번호 지정
app.listen(3000 , ()=>{
  console.log('member 접속! - http://localhost:3000/member')
  console.log('member 접속! - http://localhost:3000/member/1')
   
})


// 4. 하위페이지들 - 라우팅 

app.get('/', (req, res)=>{
  res.send('메인 접속성공!')
})

// API
app.get('/member', memberSearchQuery)       // (1) 멤버조회 - 쿼리스트링
app.get('/member/:id', memberSearchParams)  // (2) 멤버조회 - 파라미터

app.get('/add-page', memberAddPage)                  // 멤버추가 페이지 보여주기
app.post('/add', memberAdd)                 // 멤버추가

app.put('/edit/:id', memberUpdate)          // 멤버수정
app.delete('/member/:id', memberDelete)     // 멤버삭제


// (1) 멤버조회 - 쿼리스트링 - url : // http://localhost:3000/member?team=aa&postion=bb
async function memberSearchQuery(req, res) {
  const {id, team, position} = req.query
  let member = null 

  try {
    // 실행할 코드
    if(team && position) 
      member = await Member.findAll({where : {team, position}}) 
    else if(id)  
      member = await Member.findAll({where : {id}}) 
    else if(team) 
      member = await Member.findAll({where : {team}})
    else if(position) 
      member = await Member.findAll({where : {position}})
    else 
      member = await Member.findAll()

    res.render('member.ejs',{member})

  } catch (error) {
    // 에러가 생겼을 때 처리할 코드 - 서버에서 오류코드 전송
    console.error("검색 중 오류 발생:", error);
    res.status(500).send("서버 오류 발생");
  }
  
}

// (2) 상세페이지 멤버조회 - 파라미터 - url : // http://localhost:3000/member/300
async function memberSearchParams(req, res) {
  const {id} = req.params
    
  try {
    const member = await Member.findOne({where : {id}}) // 배열아님 
    
    if(member){
      res.render('member-detail.ejs',{member})
    }else{
      res.send('값을 찾을 수 없음')
    }
  } catch (error) {
    console.error("검색 중 오류 발생:", error);
    res.status(500).send("서버 오류 발생");
  }

}

// (3) 멤버추가
async function memberAddPage(req, res) {
  
  try {
    res.render('add-page.ejs')  
  } catch (error) {
    console.error("검색 중 오류 발생:", error);
    res.status(500).send("서버 오류 발생");
  }

  

}

// (3) 멤버추가
async function memberAdd(req, res) {
  const newMember = req.body
  
  try {
    const member = await Member.create(newMember)
    res.render('member.ejs',{member})  
  } catch (error) {
    console.error("검색 중 오류 발생:", error);
    res.status(500).send("서버 오류 발생");
  }

  

}

// (4) 멤버수정
async function memberUpdate(req, res) {
  const {id} = req.params


  try {
    const newInfo = req.body
    const member = await member.findeOne({where : {id}})

    Object.keys(newInfo).forEach(( prop )=>{
    member[prop] = newInfo[prop]
    })
    await member.save()
    res.render('member.ejs',{member})

  } catch (error) {

    console.error("처리 중 오류 발생:", error);
    res.status(500).send("서버 오류 발생");
  }

  

}

// (5) 멤버삭제
async function memberDelete(req, res) {
  const {id} = req.params
  try {
    const deleteCount = await Member.destroy({where : {id}})
    res.render('member.ejs',{member})

  } catch (error) {
    console.error("처리 중 오류 발생:", error);
    res.status(500).send("서버 오류 발생");
  }

}

/*
  1) 데이터 받아오기 - query, params, body
  2) 데이터 처리하기
    - 조회 : db.findAll( { where : {값} })
    - 추가 : db.create( 객체 )
    - 수정 : db.findOne( { where : {값} } )
            Object.keys(새로운값).forEach((prop)={
              기존값[prop] = 새로운값[prop]
            })
            db.save()
    - 삭제 : db.destroy({ where : {값})
  3) 렌더링
  - res.render() 

*/