let del = document.getElementsByClassName('del')

let postCommit = document.getElementById('post-commit')
let postCancel = document.getElementById('post-cancel')

// 등록버튼을 클릭하면
// (완료) input상자의 제목과 내용이 서버로 전달되서 내용이 db에 저장이 된다.
// 만약에 제목, 내용의 칸이 비어 있으면 
// 안내메시지 -> 제목을 입력/ 내용을 입력 (alret창에 메시지 띄우기)

// post-form의 submit의 기능을 막기
document.getElementById('post-form').addEventListener('submit', function(event){
  // 기본 동작(서버에 제출)을 막음
  event.preventDefault() 

  // 제목과 내용 입력 요소를 가져옴
  let postTitle = document.getElementById('post-title').value;
  let postContent = document.getElementById('post-content').value;
  
  // 내용이 비어 있는지 확인
  if (postTitle == "") {
    alert('제목을 입력해주세요!');
  } else if (postContent == "") {
    alert('내용을 입력해주세요!')
  } else {
    // 내용이 비어 있지 않으면 폼 제출
    this.submit()
  }
});

// 개수가 여러개인 요소에 이벤트 걸때 기본 구문 (클래스 요소 가져올때)

for(let i = 0; i < del.length; i++){

  del[i].addEventListener('click',function(e){

    // 클릭한 대상의 data속성중 id인의 값을 가져온다  -->  data-id="값"
    let id = e.target.dataset.id 
    let txt = e.target.textContent
    
    if(txt == "삭제"){
      postDelete(id)
    } else{

    }

    

  })
  
}



const blogItems = document.querySelectorAll('.blog-item')

blogItems.forEach(item => {
  
  const titleInput = item.querySelector('.blog-title');
  const contentInput = item.querySelector('.blog-content');
  const editButton = item.querySelector('.edit');
  const delButton = item.querySelector('.del');

  editButton.addEventListener('click', (e) => {
    
    const id = e.target.dataset.id
    console.log(id)
    titleInput.classList.toggle('editable');
    contentInput.classList.toggle('editable');

    if (titleInput.classList.contains('editable')) {
      editButton.textContent = '저장';
      delButton.textContent = '취소';
      titleInput.removeAttribute('readonly');
      contentInput.removeAttribute('readonly');


    } else {
      editButton.textContent = '수정';
      delButton.textContent = '삭제';
      titleInput.setAttribute('readonly', 'readonly');
      contentInput.setAttribute('readonly', 'readonly');

      let newPost = {
        title : titleInput.value, 
        content : contentInput.value
      }
      postEdit(id, newPost)


    }
  })

})


function postDelete(id){
  fetch('/'+id , {method : 'DELETE'})
      .then((r)=>{r.text()}) // 성공했을때 메시지
      .then((r)=>{ // 성공했을 때 처리할 내용
        window.location.href="/"
      })
      .catch((error)=>{
        console.error()
      })
}

function postEdit(id, newPost){
  fetch('/'+id , {
    method : 'PUT',
    headers: { 'Content-Type': 'application/json'}, 
    body: JSON.stringify(newPost)
  })
      .then((r)=>{r.text()}) // 성공했을때 메시지
      .then((r)=>{ // 성공했을 때 처리할 내용
        window.location.href="/"
      })
      .catch((error)=>{
        console.error()
      })
}
