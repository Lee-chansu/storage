const express = require('express')
const app = express()
const db = require('./models')
const {Member} = db

app.set('view engine', 'ejs')
app.use(express.static(__dirname + '/public'))
app.use(express.json()) // json형태로 데이터 처리
app.use(express.urlencoded({extended : true}))  // queryString 방식의 데이터 처리


app.listen(3000 , ()=>{
  console.log('member 접속! - http://localhost:3000')   
})


// 하위페이지들 - 라우팅 
app.get('/', (req, res)=>{
  res.send('메인 접속성공!')
})

// 추가 페이지 조회
app.get('/add-page', memberAddPage) 
async function memberAddPage(req, res) {
  try {
    res.render('add-page.ejs')
  } catch (error) {
    console.error("검색 중 오류 발생:", error);
    res.status(500).send("서버 오류 발생");
  }

}

// 수정 페이지 조회
app.get('/edit-page/:id', memberUpdatePage) 
async function memberUpdatePage(req, res) {
  const {id} = req.params
  try{
    const member = await  Member.findOne({where: {id}})  
    res.render('edit-page.ejs', {member})
  }catch{
    console.error("처리 중 오류 발생:", error);
    res.status(500).send("서버 오류 발생");
  }
  
}

// (문제1) 전체 멤버조회
app.get('url', async function (req, res) {

  try {

    
  } catch (error) {
    console.error("검색 중 오류 발생:", error);
    res.status(500).send("서버 오류 발생");
  }
  
})

// (문제 2) 상세페이지 멤버조회



// (문제 3) 추가 페이지



// (문제 4) 멤버 수정 처리



// (문제 5) 멤버 삭제 처리
